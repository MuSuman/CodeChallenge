﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    public class Magazine
    {
        public int id { get; set; }
        public string firstname { get; set; }
        public string lastname { get; set; }
        public List<int> magazineIds { get; set; }
    }
}
